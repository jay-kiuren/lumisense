import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import 'widgets/analytics_range_selector.dart';
import 'widgets/department_card.dart';
import 'widgets/floor_plan_widget.dart';
import 'widgets/action_center.dart';
import 'widgets/summary_panel.dart';
import '../../../core/domain/entities/zone_snapshot.dart';
import '../../../core/domain/value_objects/noise_level.dart';

import '../../../core/services/supabase/supabase_telemetry_repository.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final _repository = SupabaseTelemetryRepository();
  late final Stream<List<ZoneSnapshot>> _liveZonesStream;

  @override
  void initState() {
    super.initState();
    _repository.initialize();
    _liveZonesStream = _repository.watchLiveZones();
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();

    return ColoredBox(
      color: AppColors.workspaceBg,
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 64,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Dashboard',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              color: AppColors.textPrimary,
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _formattedDate(now),
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: AppColors.textSecondary,
                              fontSize: 13,
                            ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  const AnalyticsRangeSelector(),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: StreamBuilder<List<ZoneSnapshot>>(
                stream: _liveZonesStream,
                builder: (context, snapshot) {
                  final liveZones = snapshot.data;
                  final displayZones = _mergeWithDefaults(liveZones ?? []);

                  return Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(
                        flex: 6,
                        child: FloorPlanWidget(liveZones: liveZones),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        flex: 3,
                        child: _LiveZonesPanel(zones: displayZones),
                      ),
                      const SizedBox(width: 16),
                      const Expanded(
                        flex: 3,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            ActionCenter(),
                            SizedBox(height: 16),
                            Expanded(child: SummaryPanel()),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Ensures all 3 department zones are always visible.
  /// Live data overrides defaults; missing zones get placeholders.
  List<ZoneSnapshot> _mergeWithDefaults(List<ZoneSnapshot> live) {
    const defaultZones = [
      ('1', 'IT Department'),
      ('2', 'CS Department'),
      ('3', 'Engineering Department'),
    ];

    final Map<String, ZoneSnapshot> merged = {};

    // Start with defaults
    for (final (id, name) in defaultZones) {
      merged[id] = ZoneSnapshot(
        zoneId: id,
        zoneName: name,
        temperatureC: 25.0,
        noiseDb: 0,
        noiseLevel: NoiseLevel.quiet,
        soundClass: 'waiting',
        alertRaised: false,
        updatedAt: DateTime.now(),
      );
    }

    // Override with live data
    for (final z in live) {
      merged[z.zoneId] = z;
    }

    return merged.values.toList();
  }

  String _formattedDate(DateTime dt) {
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December',
    ];
    const days = [
      'Monday', 'Tuesday', 'Wednesday', 'Thursday',
      'Friday', 'Saturday', 'Sunday',
    ];
    return '${days[dt.weekday - 1]}, ${months[dt.month - 1]} ${dt.day}, ${dt.year}';
  }
}

class _LiveZonesPanel extends StatelessWidget {
  const _LiveZonesPanel({required this.zones});

  final List<ZoneSnapshot> zones;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: AppColors.shadowMedium,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Live Zones',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: AppColors.textPrimary,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
          ),
          const SizedBox(height: 14),
          Expanded(child: _buildZones(context)),
        ],
      ),
    );
  }

  Widget _buildZones(BuildContext context) {
    return ListView.separated(
      padding: EdgeInsets.zero,
      itemCount: zones.length,
      separatorBuilder: (context, index) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Divider(color: AppColors.surfaceHighlight.withValues(alpha: 0.8), height: 1),
      ),
      itemBuilder: (context, index) => DepartmentCard(snapshot: zones[index]),
    );
  }
}
